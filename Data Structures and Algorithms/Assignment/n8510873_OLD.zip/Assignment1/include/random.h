//
//  random.h
//  PokerEval
//
//  Created by Connor Livsey on 18/04/13.
//  Copyright (c) 2013 Connor Livsey. All rights reserved.
//

#ifndef RANDOM_H
#define RANDOM_H
#include <iostream>
#include <cstdlib>
#include <ctime>

class Random
{

private:
    int low;
    int high;
    void Randomise();

public:
    Random(int low, int high);
    ~Random();
    int RandomInt();
};

#endif /* defined(RANDOM_H) */
