//
//  hand.h
//  PokerEval
//
//  Created by Connor Livsey on 19/04/13.
//  Copyright (c) 2013 Connor Livsey. All rights reserved.
//

#ifndef HAND_H
#define HAND_H

#include <iostream>
#include <vector>
#include <list>
#include <sstream>
#include "card.h"
#include "cardComparer.h"
#include <math.h>
#include <algorithm>

enum HandType
{
    HIGH_CARD, ONE_PAIR, TWO_PAIRS, THREE_OF_A_KIND,
    STRAIGHT, FLUSH, FULL_HOUSE, FOUR_OF_A_KIND,
    STRAIGHT_FLUSH
};

const string HAND_TYPE[9] =
{
    "High Card", "One Pair", "Two Pairs", "Three of a Kind",
    "Straight", "Flush", "Full House", "Four of a Kind",
    "Straight Flush"
};

class Hand
{
public:
    Hand(int player);
    ~Hand();
    void AddCard(Card *card);
    void Evaluate();
    int GetValue();
    HandType GetHandType();
    void ClearHand();
    string ToString();
private:
    const int CARDS_IN_HAND = 5;
    const int FIRST = 0;
    const int FIRST_CARD = 1;
    const int ONE_CARD = 1;
    const int ONE_RANK = 1;
    vector<Card*> hand;

    HandType type;
    enum Kind
    {
        FOUR = 4,
        THREE = 3,
        PAIR = 2
    };

    int Id;
    int value;
    void EvaluateType();
    void EvaluateValue();
    void EvalStandard();
    void EvalStraight();
    bool IsFlush();
    bool IsStraight();
    bool IsN_Of_A_Kind(Kind kind, bool sort);
    bool IsPair(Kind kind, bool two, bool sort);
    std::stringstream out;
};

#endif /* defined(HAND_H) */
