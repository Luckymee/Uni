//
//  cardComparer.h
//  PokerEval
//
//  Created by Connor Livsey on 19/04/13.
//  Copyright (c) 2013 Connor Livsey. All rights reserved.
//

#ifndef CARD_COMPARER
#define CARD_COMPARER

#include <iostream>
#include "card.h"

class CardComparer
{
public:
    bool operator() (Card*, Card*);
};
#endif /* defined(CARD_COMPARER) */
