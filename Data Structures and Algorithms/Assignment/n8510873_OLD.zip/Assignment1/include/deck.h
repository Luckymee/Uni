//
//  deck.h
//  PokerEval
//
//  Created by Connor Livsey on 18/04/13.
//  Copyright (c) 2013 Connor Livsey. All rights reserved.
//

#ifndef DECK_H
#define DECK_H

#include <iostream>
#include "card.h"
#include "random.h"

const int CARDS_IN_DECK = 52;

class Deck
{

public:
    Deck();
    ~Deck();
    Card* DealNextCard();
    void Shuffle();
    void DisplayDeck();

private:
    const int SHUFFLE_AMOUNT = 1000;
    const int START = 0;
    Card** deck;
    int cardsDealt;
    void SwapCard(int pickPos, int placePos);
};

#endif /* defined(DECK_H) */
